#include <iostream>
#include "queueArr.h"

int main(){
    //create queue
    queueArr<char> q(6); 

    //Enqueue
    q.Enqueue('J');
    q.Enqueue('A');
    q.Enqueue('M');
    q.Enqueue('E');
    q.Enqueue('S');
    
    //check front and back
    std::cout<<q.Front()<<std::endl;
    std::cout<<q.Back()<<std::endl;

    //Dequeue
    q.Dequeue();
    q.Dequeue();

    //check front and back
    std::cout<<q.Front()<<std::endl;
    std::cout<<q.Back()<<std::endl;
    //copy
    queueArr<char> qTPi = q; //"Que - T - Pi haha"
    std::cout<<qTPi.Front()<<std::endl;
    qTPi.Back();

    //return 1/0 if empty or full
    q.Clear();
    std::cout<<q.Full()<<std::endl;
    q.Empty();
    return 0;
}