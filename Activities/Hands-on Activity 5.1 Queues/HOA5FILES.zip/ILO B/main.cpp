#include <iostream>
#include "queueLL.h"

int main(){

    qNode<char>* front = nullptr;
    qNode<char>* back = nullptr;

    enqueue('J', &front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;
    enqueue('A', &front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;
    enqueue('M', &front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;
    enqueue('E', &front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;
    enqueue('S', &front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;

    //display all:
    displayAll(front);
    
    //dequeue
    dequeue(&front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;
    dequeue(&front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;
    dequeue(&front, &back);
    dequeue(&front, &back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;
    dequeue(&front, &back); //should be empty

    enqueue('J', &front, &back);
    getFront(front);
    enqueue('A', &front, &back);
    getBack(back);
    std::cout<<front-> data<<" "<<back->data<<std::endl;

    //remove again
    dequeue(&front, &back);
    dequeue(&front, &back);

    //empty check
    getBack(back);
    getFront(front);
    displayAll(front);
    return 0;
}