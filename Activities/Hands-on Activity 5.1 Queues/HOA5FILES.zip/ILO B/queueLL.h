#ifndef QUEUELL_H
#define QUEUELL_H

//create the class node
template <typename T>
class qNode{
    public:
    T data;
    qNode<T>* next;
};

//creates the new node
template <typename T>
qNode<T>* new_node(T newData){
    qNode<T>* newNode = new qNode<T>;
    newNode->data = newData;
    newNode->next = nullptr;
    return newNode;
}

//insert/enqueue
template <typename T>
void enqueue(T newData, qNode<T>** frontPtr, qNode<T>** backPtr){
    //create new node
    qNode<T>* newNode = new_node(newData);

    //insert into empty queue
    if((*frontPtr) == nullptr && (*backPtr) == nullptr){
        (*frontPtr) = newNode;
        (*backPtr) = newNode;
    }
    //insert an item into non empty queue
    (*backPtr)->next = newNode;
    (*backPtr) = newNode;

}

//delete/dequeue
template <typename T>
void dequeue(qNode<T>** frontPtr, qNode<T>** backPtr){

    //create temporary mode
    qNode<T>* deleteNode = nullptr;
    deleteNode = (*frontPtr);

    //add a check if queue is already empty
    if((*frontPtr) == nullptr && (*backPtr) == nullptr){
        std::cout<<"The queue is empty!"<<std::endl;
        return;
     }

    //check if the queue has only 1 node
    if((*frontPtr)->next == nullptr && (*backPtr)->next == nullptr){
        (*frontPtr) = nullptr;
        (*backPtr) = nullptr;
        delete deleteNode;
        return;
    }
    //delete the node
    (*frontPtr) = (*frontPtr)->next;
    deleteNode->next = nullptr;
    delete deleteNode;
}

//check the front
template<typename T>
void getFront(qNode<T>* frontPtr){
    if (frontPtr == nullptr){
        std::cout<<"Queue is empty!"<<std::endl;
        return;
    }

    std::cout<<"The current front: "<<frontPtr->data<<std::endl;

}

//check the back
template<typename T>
void getBack(qNode<T>* backPtr){
    if (backPtr == nullptr){
        std::cout<<"Queue is empty!"<<std::endl;
        return;
    }

    std::cout<<"The current back: "<<backPtr->data<<std::endl;

}

//display all
template <typename T>
void displayAll(qNode<T>* frontPtr){
     if(frontPtr == nullptr){
        std::cout<<"The queue is empty!"<<std::endl;
        return;
     }
     std::cout<<"The current Queue: ";
     while(frontPtr != nullptr){
        std::cout<<frontPtr->data<<" ";
        frontPtr = frontPtr->next;
     }
     std::cout<<"\n";

}



#endif