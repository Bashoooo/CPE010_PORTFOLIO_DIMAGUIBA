#ifndef QUEUEARR_H
#define QUEUEARR_H

#include <iostream>


template <typename T>
class queueArr{
    private:
        T* q_array;
        size_t q_capacity;
        size_t q_size;
        int q_front;
        int q_back;

    public:
        queueArr(size_t capacity);
        ~queueArr();

        bool Empty();
        bool Full();

        size_t Size();

        void Clear();

        void Enqueue(T newData);
        void Dequeue();

        T Front();
        T Back();

        queueArr(const queueArr &other);
        queueArr &operator = (const queueArr &other);

};

template <typename T>
queueArr<T>::queueArr(size_t capacity){
    //define capacity of array
    q_capacity = capacity;
    //set the size to 0
    q_size = 0;
    //set the front and back to 0 and -1
    q_front = 0;
    q_back = -1;
    //allocate a new space for the q_array that was created
    q_array = new T[q_capacity];
}   


template <typename T>
queueArr<T>::~queueArr(){
    delete[] q_array;
    std::cout<<"destructor was called\n";
}

template <typename T>
queueArr<T>::queueArr(const queueArr &other){
        std::cout<<"Queue Copied!"<<std::endl;
        q_capacity = other.q_capacity;
        q_size = other.q_size;
        q_front = other.q_front;
        q_back = other.q_back;
        //create a new array to avoid pointing to the same array
        q_array = new T[q_capacity];
        for(int i = 0; i < q_capacity; i++){
            q_array[i] = other.q_array[i];
        }
    }


template <typename T>
bool queueArr<T>::Empty(){
    return q_size == 0;
}

template <typename T>
bool queueArr<T>::Full(){
    return q_size == q_capacity;

}

template <typename T>
size_t queueArr<T>::Size(){
    return q_size;
}

template <typename T>
void queueArr<T>::Clear(){
    q_front = 0;
    q_back = -1;
    q_size = 0;
    
    return;
}

template <typename T>
T queueArr<T>::Front(){

    //check if queue is not empty
    if(Empty()){
        std::cout<<"The queue is empty"<<std::endl;
        return T{};//std::optional
    }
    return q_array[q_front]; 
}

template <typename T>
T queueArr<T>::Back(){

    //check if queue is not empty
    if(Empty()){
        std::cout<<"The queue is empty"<<std::endl;
        return T{};//std::optional
    }
    return q_array[q_back]; 
}

template <typename T>
void queueArr<T>::Enqueue(T newData){
    //check if full
    if(Full()){
        std::cout<<"queue is full!"<<std::endl;
        return;
    }
    //compute for back index
    q_back = (q_back + 1) % q_capacity;
    //store
    q_array[q_back] = newData;
    //increment size
    q_size++;
}

template <typename T>
void queueArr<T>::Dequeue(){
    //check if full
    if(Empty()){
        std::cout<<"queue is empty!"<<std::endl;
        return;
    }
    //compute for back index
    q_front = (q_front + 1) % q_capacity;
    //decrement size
    q_size--;

    //what if empty?
    if (q_size == 0){
        Clear();
        return;
    }
}

#endif