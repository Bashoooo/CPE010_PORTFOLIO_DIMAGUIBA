#include<iostream>
#include <queue>

void display(std::queue<char> copyQ);

int main(){
    //create an object
    std::queue<char> myQ;
    myQ.push('J');
    myQ.push('A');
    myQ.push('M');
    myQ.push('E');
    myQ.push('S');
    display(myQ);

    //try all member functions:
    //empty
    std::cout<<myQ.empty()<<std::endl;
    //size
    std::cout<<myQ.size()<<std::endl;
    //front
    std::cout<<myQ.front()<<std::endl;
    //back
    std::cout<<myQ.back()<<std::endl;
    //pop
    std::cout<<"Popping: "<<myQ.front()<<std::endl;
    myQ.pop();
    //display
    display(myQ);
    //push
    std::cout<<"Pushing: J"<<std::endl;
    myQ.push('J');
    //display
    display(myQ);
    return 0;
}

void display(std::queue<char> copyQ){
    //create copy of queue that was passed
    std::queue<char> c = copyQ;
    while(!c.empty()){
        std::cout<<" "<<c.front();
        c.pop();
    }
    std::cout<<"\n";
}

