#ifndef QUEUELL_H
#define QUEUELL_H


//create the class node
template <typename T>
class Printer{
    public:
    T data;
    Printer<T>* next;
};


//insert/enqueue
template <typename T>
void enqueue(T newData, Printer<T>** frontPtr, Printer<T>** backPtr){
    //create new node
    Printer<T>* newNode = new Printer<T>;
    newNode->data = newData;
    newNode->next = nullptr;

    //insert into empty queue
    if((*frontPtr) == nullptr && (*backPtr) == nullptr){
        (*frontPtr) = newNode;
        (*backPtr) = newNode;
        std::cout<<"Queued: "<<std::endl;
        std::cout<<"ID: "<<(*backPtr)->data.id<<" ";
        std::cout<<"pages: "<<(*backPtr)->data.pages<<" ";
        std::cout<<"Username: "<<(*backPtr)->data.username<<std::endl;
        return;
    }
    
    //insert an item into non empty queue
    (*backPtr)->next = newNode;
    (*backPtr) = newNode;

    std::cout<<"Queued: "<<std::endl;
    std::cout<<"ID: "<<(*backPtr)->data.id<<" ";
    std::cout<<"pages: "<<(*backPtr)->data.pages<<" ";
    std::cout<<"Username: "<<(*backPtr)->data.username<<std::endl;
}

//delete/dequeue
template <typename T>
void dequeue(Printer<T>** frontPtr, Printer<T>** backPtr){

    //create temporary mode
    Printer<T>* deleteNode = nullptr;
    deleteNode = (*frontPtr);

    //add a check if queue is already empty
    if((*frontPtr) == nullptr && (*backPtr) == nullptr){
        std::cout<<"The queue is empty!"<<std::endl;
        return;
     }
    std::cout<<"Now Printing: "<<std::endl;
    std::cout<<"ID: "<<(*frontPtr)->data.id<<" ";
    std::cout<<"pages: "<<(*frontPtr)->data.pages<<" ";
    std::cout<<"Username: "<<(*frontPtr)->data.username<<std::endl;

    //check if the queue has only 1 node
    if((*frontPtr)->next == nullptr && (*backPtr)->next == nullptr){
        (*frontPtr) = nullptr;
        (*backPtr) = nullptr;
        delete deleteNode;
        return;
    }
    //delete the node
    (*frontPtr) = (*frontPtr)->next;
    deleteNode->next = nullptr;
    delete deleteNode;
}

//check the front
template<typename T>
void getFront(Printer<T>* frontPtr){
    if (frontPtr == nullptr){
        std::cout<<"Queue is empty!"<<std::endl;
        return;
    }

    std::cout<<"Next in Queue: "<<std::endl;
    std::cout<<"ID: "<<frontPtr->data.id<<" ";
    std::cout<<"pages: "<<frontPtr->data.pages<<" ";
    std::cout<<"Username: "<<frontPtr->data.username<<std::endl;

}

//check the back
template<typename T>
void getBack(Printer<T>* backPtr){
    if (backPtr == nullptr){
        std::cout<<"Queue is empty!"<<std::endl;
        return;
    }
    std::cout<<"Last Queued: "<<std::endl;
    std::cout<<"ID: "<<backPtr->data.id<<" ";
    std::cout<<"pages: "<<backPtr->data.pages<<" ";
    std::cout<<"Username: "<<backPtr->data.username<<std::endl;
}

//display all
template <typename T>
void displayAll(Printer<T>* frontPtr){
     if(frontPtr == nullptr){
        std::cout<<"The queue is empty!"<<std::endl;
        return;
     }
     std::cout<<"The current Queue:"<<std::endl;
     while(frontPtr != nullptr){
        std::cout<<"ID: "<<frontPtr->data.id<<" ";
        std::cout<<"pages: "<<frontPtr->data.pages<<" ";
        std::cout<<"Username: "<<frontPtr->data.username<<std::endl;
        frontPtr = frontPtr->next;
     }
     std::cout<<"\n";

}



#endif