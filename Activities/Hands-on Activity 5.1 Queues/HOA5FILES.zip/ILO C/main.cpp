#include <iostream>
#include <string>
#include "queueLL.h"

class Job{
    public:
        int id, pages;
        std::string username;

        Job(int idNo = 0, int pageNo = 0, std::string userName = ""){
            id = idNo;
            pages = pageNo;
            username = userName;
        }

};
    Printer<Job>* front = nullptr;
    Printer<Job>* back =  nullptr;

int option, pages, id;
std::string username;

int main(){
    while (option !=  6){
    std::cout<<"   <A \"Printer\">\nSelect an option:"<<std::endl;
    std::cout<<"1. Print All\n2. Queue a File\n3. View Next\n4. View Last \n5. View Queue\n";
    std::cout<<"6. Quit"<<std::endl;
    std::cout<<"Enter Choice here: ";

    while(!(std::cin>>option)){
        std::cout<<"Invalid input!\n";
        std::cin.clear();
        std::cin.ignore(10000, '\n');
    }

   switch(option){
      case 1:
        while(front != nullptr){
         dequeue(&front, &back);
        }
         break;
      
      case 2:
      {
        std::cout<<"ID Number: ";
        std::cin >> id;

        std::cout<<"Number of Pages: ";
        std::cin>>pages;

        std::cout<<"Enter Username: ";
        std::cin.ignore();
        std::getline(std::cin, username);

        Job j(id,pages,username);
        enqueue(j, &front, &back);
        break;
      }

      case 3:
      {
         getFront(front);
         break;
      }

      case 4:
      getBack(back);
      break;

      case 5:
      displayAll(front);
      break;

      case 6:
      break;

      default:
         std::cout<<"Invalid Choice\n";

      }

   }
   return 0;
}