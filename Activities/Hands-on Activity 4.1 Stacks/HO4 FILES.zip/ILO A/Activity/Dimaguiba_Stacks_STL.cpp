#include <iostream>
#include <stack> //call the stack from STL

int main(){
    
    std::stack <int> newStack; //created an onject
    std::stack<int> newerStack;
    //test if stack is empty
    std::cout<<"Is the stack empty? "<<newStack.empty()<<std::endl;

    //insert 3 element
    newStack.push(3);
    std::cout<<"Top of stack: "<< newStack.top()<<std::endl;
    newStack.push(2);
    std::cout<<"Top of stack: "<< newStack.top()<<std::endl;
    newStack.push(1);
    std::cout<<"Top of stack: "<< newStack.top()<<std::endl;

    //test if stack is empty
    std::cout<<"Is the stack empty? "<<newStack.empty()<<std::endl;

    std::cout<<"Size of the stack is: "<<newStack.size()<<std::endl;

    newStack.push(6);
    std::cout<<"Top of stack: "<< newStack.top()<<std::endl;
    newStack.push(7);
    std::cout<<"Top of stack: "<< newStack.top()<<std::endl;
    newStack.push(8);
    std::cout<<"Top of stack: "<< newStack.top()<<std::endl;

    std::cout<<"Size of the stack is: "<<newStack.size()<<std::endl;

    
     //make second stack
    newerStack.push(9);
    std::cout<<"Top of stack: "<< newerStack.top()<<std::endl;
    newerStack.push(10);
    std::cout<<"Top of stack: "<< newerStack.top()<<std::endl;
    newerStack.push(11);
    std::cout<<"Top of stack: "<< newerStack.top()<<std::endl;
    newerStack.push(12);
    std::cout<<"Top of stack: "<< newerStack.top()<<std::endl;
    newerStack.push(13);
    std::cout<<"Top of stack: "<< newerStack.top()<<std::endl;
    newerStack.push(14);
    std::cout<<"Top of stack: "<< newerStack.top()<<std::endl;

    // swap the content of public member functions
    newStack.swap(newerStack);

    //emplace
    newStack.emplace(67);
    std::cout<<"Top of stack: "<< newStack.top()<<std::endl;

    //popping the stack
    while (!newStack.empty()){
        std::cout<<newStack.top()<<" \n";
        newStack.pop();
    }

    return 0;

}