#ifndef LISTSTACK_H
#define LISTSTACK_H

//class node with data and next members
template <typename T>
class Node{
    public:
        T data;
        Node<T>* next = nullptr;
};

//create a pointer/reference tip that points to current head

//global
template <typename T>
Node<T>* head = nullptr;

//pushing
template <typename T>
void push(T newData){
    //create new node
    Node<T>* newNode = new Node<T>;
    //assign data to the new node
    newNode->data = newData;
    //point the newNode to current top
    newNode->next = head<T>;
    //assign the new top to the Node
    head<T> = newNode;
}

//is empty
template <typename T>
bool isEmpty(){
    return head<T> == nullptr;
}

template <typename T>
T pop(){
    //if stack is empty
    if (isEmpty<T>()){
        std::cout<<"Stack underflow!"<<std::endl;
    }

    //saving current top node to a temporary variable
    Node<T>* temp =  head<T>;

    //store the data to a temp variable
    T tempVal = temp->data;

    //move head to next node
    head<T> = head<T>->next;
    //free memory
    delete temp;
    //return temporary variable data
    return tempVal;
}

template <typename T>
void Top(){
    //what if the stack is empty
    if(isEmpty<T>()){
        std::cout<<"Stack Underflow!"<<std::endl;
        return;
    } 
    std::cout<<"Current Top:"<<head<T>->data<<std::endl;
}

template <typename T>
void displayAll(){
    if (isEmpty<T>()){
        std::cout<<"Stack Underflow!"<<std::endl;
        return;
    }
    Node<T>* current = head<T>; 
    std::cout<<"Current Stack: ";
    while (current != nullptr){
        std::cout<<current->data<<" ";
        current = current->next;
    }
     std::cout<<std::endl;
}


#endif