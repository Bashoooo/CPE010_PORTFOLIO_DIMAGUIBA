#include <iostream>
#include <string>

const size_t maxCap = 100;
int top = -1;
char stack[maxCap];
char newData;
std::string checkword;
int choice, elements;
//prototyping
bool isFull();
bool isEmpty();
void push(char newData);
void pop();
void Top();


int main(){
    std::cout<<"Input string: ";
    std::cin>>checkword;
    elements = checkword.length();
    for (int i = 0; i < checkword.length(); i++){
        if (checkword[i] == '(' or checkword[i] == '[' or checkword[i] == '{' ){
            std::cout<<"Pushing: "<<checkword[i]<<std::endl;
            push(checkword[i]);
        }
        else if (checkword[i] == ')' || checkword[i] == '}' || checkword[i] == ']' ){
            if(isEmpty()){
                std::cout<<"ERROR! STACK EMPTY!"<<std::endl;
                return 0;
            }
           
            if(stack[top] == '(' && checkword[i] == ')' || stack[top] == '{' && checkword[i]=='}' || stack[top] == '[' && checkword[i] == ']' ){
                pop();
        }
            
        }
    }
    if(!isEmpty()){
        std::cout<<"Error: NOT VALID"<<std::endl;
    }
    else{
        std::cout<<"IS VALID"<<std::endl;
    }
    return 0;
}


bool isEmpty(){
    if (top == -1){
        return true;
    }
    return false;
}

bool isFull(){
    //not equal to maxCap
    if(top >= elements - 1){
        std::cout<<"Stack Overflow"<<std::endl;
        return true;
    }
    return false;
}

void push(char newData){
    //check if stack is full, if yes, return error
    if (isFull()){
        return;
    }
    //store inside stack
    stack[++top] = newData;
}

void pop(){
    // check if empty
    if (isEmpty()){
        return;
    }

    //display element to be popped
    std::cout<<"Popping: "<<stack[top]<<std::endl;

    //decrement top:
    top--;
}

void Top(){
    //error checking 
    if(isEmpty()){
        std::cout<<"Stack Underflow"<<std::endl;
        return;
    }
    //display top
    std::cout<<"The top element is: "<<stack[top]<<std::endl;

}

void displayAll(){
    if (isEmpty()){
        std::cout<<"Nothing to display!"<<std::endl;
        return;
    }
    for(int i = top; i >= 0; i--){
        std::cout<<stack[i]<<" ";
    }
    std::cout<<std::endl;
}