#include <iostream>
#include <string>
#include "listStack.h"

std::string checkword;
/*
1. Create a Stack.
2. While(end of input is not reached) {
a) If the character read is not a symbol to be balanced, ignore it.
b) If the character is an opening symbol, push it onto the stack.
c) If it is a closing symbol:
i) Report an error if the stack is empty.
ii) Otherwise, pop the stack.
d) If the symbol popped is not the corresponding opening symbol, report an error.
3. At the end of input, if the stack is not empty: report an error.*/

int main(){
    std::cout<<"Input string: ";
    std::cin>>checkword;
    for (int i = 0; i < checkword.length(); i++){
        if (checkword[i] == '(' or checkword[i] == '[' or checkword[i] == '{' ){
            std::cout<<"Pushing: "<<checkword[i]<<std::endl;
            push(checkword[i]);
        }
        else if (checkword[i] == ')' || checkword[i] == '}' || checkword[i] == ']' ){
            if(isEmpty<char>()){
                std::cout<<"ERROR! STACK EMPTY!"<<std::endl;
                return 0;
            }
            
            char top = head<char>->data;
            if(top == '(' && checkword[i] == ')' || top == '{' && checkword[i]=='}' || top == '[' && checkword[i] == ']' ){
             std::cout<<"Popping: "<<top;
                pop<char>();
                std::cout<<std::endl;
        }
            
        }
    }
    if(!isEmpty<char>()){
        std::cout<<"Error: NOT VALID"<<std::endl;
    }
    else{
        std::cout<<"IS VALID"<<std::endl;
    }
    return 0;
}

