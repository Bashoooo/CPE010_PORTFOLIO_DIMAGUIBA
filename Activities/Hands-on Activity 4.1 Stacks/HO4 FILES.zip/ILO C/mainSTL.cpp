#include <iostream>
#include <string>
#include <stack>

std::string checkword;
char match;
std::stack<char> m;
int main(){
    std::cout<<"Input string: ";
    std::cin>>checkword;
    for (int i = 0; i < checkword.length(); i++){
        if (checkword[i] == '(' or checkword[i] == '[' or checkword[i] == '{' ){
            std::cout<<"Pushing: "<<checkword[i]<<std::endl;
            m.push(checkword[i]);
        }
        else if (checkword[i] == ')' || checkword[i] == '}' || checkword[i] == ']' ){
            if(m.empty()){
                std::cout<<"ERROR! STACK EMPTY!"<<std::endl;
                return 0;
            }

            if(m.top() == '(' && checkword[i] == ')' || m.top() == '{' && checkword[i]=='}' || m.top() == '[' && checkword[i] == ']' ){
             std::cout<<"Popping: "<<m.top()<<std::endl;
                m.pop();
        }
            
        }
    }
    if(!m.empty()){
        std::cout<<"Error: NOT VALID"<<std::endl;
    }
    else{
        std::cout<<"IS VALID"<<std::endl;
    }
    return 0;
}