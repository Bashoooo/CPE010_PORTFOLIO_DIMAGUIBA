#include <iostream>
#include <cstdlib>
#include <time.h>
const int maxVal = 10;

//Algorithm Unique (A)


bool alUnique (int arr[], int A){
    for (int i = 0; i < A; i++){ 
        for(int j = i + 1; j < A; j++){
            if (arr[i] == arr[j]){
                return false;
            }
        }
    }
    return true;
}

int main(){

    //generate random set
    int set[maxVal];
    srand(time(0));

    for (int i = 0; i < maxVal; i++){
        set[i] = rand() % 10 + 1;
    }

    for(int i = 0; i < maxVal; i++){
        std::cout<<set[i]<<" ";
    }

    std::cout<<std::endl;

    std::cout<<alUnique(set, maxVal);

    return 0;
}
