/*
Algorithm rpower(int x, int n):
1 if n == 0 return 1
2 else return x*rpower(x, n-1)
Algorithm brpower(int x, int n):
1 if n == 0 return 1
2 if n is odd then
3 y = brpower(x, (n-1)/2)
4 return x*y*y
5 if n is even then
6 y = brpower(x, n/2)
7 return y*y
*/

#include <iostream>
#include <cstdlib>
#include <time.h>

 int rpower(int x, int n){
    if(n ==0){
        return 1;
    }

    else{
        return x*rpower(x, n - 1);
    }

}


int brpower(int x, int n){
    int y;
    if(n == 0){
        return 1;
    }
    if((n % 2) != 0){
        y = brpower(x, (n-1)/2);
        return x*y*y;
    }

    if((n % 2) == 0){
        y = brpower(x,n/2);
        return y*y;
    }

}

int main(){
    int testVal = 2;
    int n = 10;

    std::cout<<rpower(testVal, n)<<std::endl;
    std::cout<<brpower(testVal, n)<<std::endl;
    return 0;
}