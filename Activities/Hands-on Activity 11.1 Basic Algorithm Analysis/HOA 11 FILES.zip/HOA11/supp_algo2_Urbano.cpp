#include <iostream>

int rpower(int x, int n) {
    if (n == 0) return 1;
    return x * rpower(x, n - 1);
}

int brpower(int x, int n) {
    if (n == 0) return 1;
    if (n % 2 != 0) { 
        int y = brpower(x, (n - 1) / 2);
        return x * y * y;
    } else {          
        int y = brpower(x, n / 2);
        return y * y;
    }
}

int main() {
    int num1 = 2;
    int num2 = 10;


    std::cout << rpower(num1,num2) <<std::endl;
    std::cout << brpower(num1,num2)<<std::endl;

    return 0;
}



