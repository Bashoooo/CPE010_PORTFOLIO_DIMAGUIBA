#ifndef SORT2_H
#define SORT2_H
#include <iostream>
/*
shellSort(array, size)
for interval i <- size/2n down to 1
for each interval "i" in array
sort all the elements at interval "i"
end shellSort
*/

template <typename T>
void shellSort(T arr[], int arrSize){ //shellSort(array, size)
    for(int interval = arrSize/2; interval > 0; interval /= 2) { //for interval i <- size/2n down to 1
        for(int i = interval; i < arrSize; i++){ //for each interval "i" in array

            int temp = arr[i];
            int j; 

            for(j = i; j >= interval && arr[j - interval] > temp; j -= interval){ //sort all the elements at interval "i"

                arr[j] = arr[j - interval];
            }

            arr[j] = temp; // insert temp

        }
    }
}

/*
Declare an array Arr of length N
If N=1, Arr is already sorted
If N>1,
Left = 0, right = N-1
Find middle = (left + right)/2
Call merge_sort(Arr,left,middle) =>sort first half recursively
Call merge_sort(Arr,middle+1,right) => sort second half recursively
Call merge(Arr, left, middle, right) to merge sorted arrays in above steps.
Exit*/

template <typename T>
void merge(T arr[], int left, int middle, int right){

    int n1 = middle - left + 1;
    int n2 = right - middle;
    
    //temporary, creates 2 different arrays
    T L[n1];
    T R[n2];

    //copy to temporaries
    for(int i = 0; i < n1; i++){
        L[i] = arr[left + i];
    }

    for(int j = 0; j < n2; j++){
        R[j] = arr[middle + 1 + j];
    }

    int i = 0;
    int j = 0;
    int k = left;

    // Merge together
    while(i < n1 && j < n2){
        if(L[i] <= R[j]){
            arr[k] = L[i];
            i++;
        }
        else{
            arr[k] = R[j];
            j++;
        }
        k++;
    }

     //Copy remaining L
    while (i < n1) {
        arr[k] = L[i];
        i++;
        k++;
    }

    // Copy remaining R
    while (j < n2) {
        arr[k] = R[j];
        j++;
        k++;
    }

}

template <typename T>
void merge_sort(T arr[], int left, int right){
    //If N=1, Arr is already sorted
    if( left >= right){
        return;
    }

    int middle = (left + right)/2;

    merge_sort(arr, left, middle); //Call merge_sort(Arr,left,middle) =>sort first half recursively
    merge_sort(arr, middle + 1, right); //Call merge_sort(Arr,middle+1,right) => sort second half recursively
    merge(arr, left, middle, right); //Call merge(Arr, left, middle, right) to merge sorted arrays in above steps.

}


/*
quicksort(A, low, high)
begin
Declare array A[N] to be sorted
low = 1st element; high = last element; pivot
if(low < high)
begin
pivot = partition (A,low,high);
quicksort(A,low,pivot-1)
quicksort(A,pivot+1,high)
End
*/

template <typename T>
int partition(T arr[], int low, int high){
    
    //declare pivot at last index
    int pivot = arr[high];

    //lagging tracker
    int i = low - 1;

    //leading traversal
    for(int j = low; j < high; j++){
        if(arr[j] <= pivot){
            i++;
            std::swap(arr[i], arr[j]);

        }
    }

    //move pivot to element greater than i then return position
    std::swap(arr[i + 1], arr[high]);
    return i + 1;

}

template <typename T>
void quickSort(T arr[], int low, int high){
    if (low < high){
        int pivot = partition(arr, low, high); //pivot = partition (A,low,high);

        quickSort(arr, low, pivot - 1); //quicksort(A,low,pivot-1)
        quickSort(arr, pivot + 1, high); //quicksort(A,pivot+1,high)
    }
}
    

#endif