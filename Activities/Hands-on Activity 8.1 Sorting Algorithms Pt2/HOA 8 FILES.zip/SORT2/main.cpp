#include <iostream>
#include "sort2.h"
#include <cstdlib>
#include <time.h>

const int maxSize = 100;

int main(){
    int dataArr[maxSize];
    srand(time(0));
    for (int i = 0; i < maxSize; i++ ){
        dataArr[i] = rand() % 10 + 1;
    }

    std::cout<<"Unsorted list:"<<std::endl;
     for (int i = 0; i < maxSize; i++ ){
       std::cout<<dataArr[i]<<" ";
    }

    std::cout<<"\n Sorted List:"<<std::endl;

    //Remove comment to test:

    //shellSort(dataArr, maxSize);
    //merge_sort(dataArr, 0, maxSize - 1);
    quickSort(dataArr, 0, maxSize - 1 );

    for (int i = 0; i < maxSize; i++ ){
       std::cout<<dataArr[i]<<" ";
    }

    return 0;
}

