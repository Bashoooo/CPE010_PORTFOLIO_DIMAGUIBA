#include <iostream>
#include "sort2 _supp.h"
#include <cstdlib>
#include <time.h>

const int maxSize = 100;

int main(){
    int dataArr[maxSize];
    srand(time(0));
    for (int i = 0; i < maxSize; i++ ){
        dataArr[i] = rand() % 10 + 1;
    }

    std::cout<<"Unsorted list:"<<std::endl;
     for (int i = 0; i < maxSize; i++ ){
       std::cout<<dataArr[i]<<" ";
    }
    

    std::cout<<"\n Sorted List:"<<std::endl;

    quickInsertSort(dataArr, 0, maxSize -1, maxSize);

    for (int i = 0; i < maxSize; i++){
       std::cout<<dataArr[i]<<" ";
    }

    //Question 2:
    int testArr[15] = {4, 34, 29, 48, 53, 87, 12, 30, 44, 25, 93, 67, 43, 19, 74};
 

    std::cout<<"\nCurrent Order:"<<std::endl;
     for (int i = 0; i < 15; i++ ){
       std::cout<<testArr[i]<<" ";
    }
    
    quickSort(testArr, 0, 15 - 1);

    std::cout<<"\nNew Order:"<<std::endl;
    for (int i = 0; i < 15; i++){
       std::cout<<testArr[i]<<" ";
    }

    return 0;
}

