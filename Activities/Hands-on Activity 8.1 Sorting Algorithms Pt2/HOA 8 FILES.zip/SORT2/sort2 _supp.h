#ifndef SORT2_SUPP_H
#define SORT2_SUPP_H
#include <iostream>

template <typename T>
void insertSort(T arr[], int low, int n){
    
    for(int i = low + 1; i < n + 1; i++){
        int temp = arr[i];
        int j = i;
        while(j > low && arr[j - 1] > temp){
            arr[j] = arr[j - 1];
            j--;
        }
        arr[j] = temp;
    }
}

template <typename T>
int partition(T arr[], int low, int high){
    
    //declare pivot at last index
    int pivot = arr[high];

    //lagging tracker
    int i = low - 1;

    //leading traversal
    for(int j = low; j < high; j++){
        if(arr[j] <= pivot){
            i++;
            std::swap(arr[i], arr[j]);

        }
    }

    //move pivot to element greater than i then return position
    std::swap(arr[i + 1], arr[high]);
    return i + 1;

}

template <typename T>
void quickSort(T arr[], int low, int high){
    if (low < high){
        int pivot = partition(arr, low, high); //pivot = partition (A,low,high);

        quickSort(arr, low, pivot - 1); //quicksort(A,low,pivot-1)
        quickSort(arr, pivot + 1, high); //quicksort(A,pivot+1,high)
    }
}

template <typename T>
void quickInsertSort(T arr[], int low, int high, int arrSize){
    while (low < high){
        
        if(high - low + 1 < arrSize){
            insertSort(arr, low, high);
            break;
        }
        else{
            int pivot = partition(arr, low, high);

            if (pivot - low < high - pivot){
                quickInsertSort(arr, low, pivot - 1, arrSize);
                low = pivot + 1;
            }
            else{
                quickInsertSort(arr, pivot + 1, high, arrSize);
                high = pivot - 1;

            }
        }
    }
}
    

#endif