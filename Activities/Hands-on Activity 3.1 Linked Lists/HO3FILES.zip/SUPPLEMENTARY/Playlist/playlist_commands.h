#ifndef PLAYLIST_COMMANDS_H
#define PLAYLIST_COMMANDS_H

#include<string>

template <typename T>
class DoubleList{
   public:
   T data;
   DoubleList<T>* next = nullptr;
   DoubleList<T>* prev = nullptr;
};


template <typename T>
void playLoop(DoubleList<T>* head){
   // if playlist is empty
   if (head == nullptr){
      std::cout<<"Playlist is empty!"<<std::endl;
      return;
   }

   while (true){
      std::cout<<"Now playing: "<<head->data<<std::endl<<std::endl;
      head = head->next;
   }
   
}

template <typename T>
void playAll(DoubleList<T>* head){
   // if playlist is empty
   if (head == nullptr){
      std::cout<<"Playlist is empty!"<<std::endl;
      return;
   }
   
   //stops the loop when all songs are played
   DoubleList<T>* firstSong = head;
   while (true){
      std::cout<<"Now playing: "<<head->data<<std::endl<<std::endl;
      head = head->next;
      if(head == firstSong){
         return;
      }
   }
}

template <typename T>
void playNext(DoubleList<T> ** currHead){
    // if playlist is empty
   if (*currHead == nullptr){
      std::cout<<"Playlist is empty!"<<std::endl;
      return;
   }

   std::cout<<"Now playing: "<<(*currHead)->next->data<<std::endl<<std::endl;
   (*currHead) = (*currHead)->next;
}

template <typename T>
void playPrev(DoubleList<T> ** currHead){
    // if playlist is empty
   if (*currHead == nullptr){
      std::cout<<"Playlist is empty!"<<std::endl;
      return;
   }

   std::cout<<"Now playing: "<<(*currHead)->prev->data<<std::endl<<std::endl;
   *currHead = (*currHead)->prev;
}

template <typename T>
void addSong(T newData, DoubleList<T>** head){

      //in an empty playlist
   if (*head == nullptr){
      DoubleList<T>* createSong = new DoubleList<T>;
      createSong->data = newData;
      createSong->next = createSong;
      createSong->prev = createSong;
      *head = createSong;
      return;
   }
   
   DoubleList<T>* currSong =  *head;
   DoubleList<T>* createSong = new DoubleList<T>;
   createSong->data = newData;

   //get to the end
   while (currSong->next != *head){
      currSong = currSong->next;
   }

  //connect
  currSong->next = createSong;
  createSong->next = *head;
  createSong->prev = currSong;
  (*head)->prev = createSong;
}

template <typename T>
void deleteSong(T findData, DoubleList<T>** currHead){
   //if empty
   if (*currHead == nullptr){
      std::cout<<"Nothing to Delete!"<<std::endl;
      return;
   }
   
   DoubleList<T>* current = *currHead;
   DoubleList<T>* first = *currHead;
   //search
   while(current->data != findData){
      if (current->next == first){
         std::cout<<"Cannot find track"<<std::endl;
         return;
      }
      current = current->next;
   }

   //if theres only one node:
   if (current->prev == *currHead && current->next == *currHead){
      delete current;
      *currHead = nullptr;
      return;
   }
   
   //if deleting head
   if(current == *currHead){
      *currHead = current->next;
      (*currHead)->prev = current->prev;
      (*currHead)->prev->next = *currHead;
      }
   
   //points it back both next and prev
   else {
      current->prev->next =current->next;
      current->next->prev = current->prev;
      }

   delete current;

}
#endif