#include <iostream>
#include <string>
#include "playlist_commands.h"


int choice = 0;
int main(){
   DoubleList<std::string>* head = new DoubleList<std::string>;
   DoubleList<std::string>* second = new DoubleList<std::string>;
   DoubleList<std::string>* third = new DoubleList<std::string>;
   DoubleList<std::string>* currentSong = head; // so switching to next and previous wont change head
   
   //Create the circle loop
   head->data = "Let it Be";
   head->next = second;
   head->prev = third;

   second->data = "Welcome to The Black Parade";
   second->prev = head;
   second->next = third;

   third->data = "I Just Threw out the Love of My Dreams";
   third->prev = second;
   third->next = head;


   while (choice != 7){
      std::cout<<"   <Song Playlist>\nSelect an option:"<<std::endl;
      std::cout<<"1. Play All Songs\n2. Add a Song\n3. Delete a Song\n4. Play Loop(use at own risk (WILL LITERALLY LOOP))\n5. Play Next Track\n";
      std::cout<<"6. Play Previous Track\n7.Quit"<<std::endl;
      std::cout<<"Enter Choice here: ";
   
   while(!(std::cin>>choice)){
      std::cout<<"Invalid input!\n";
      std::cin.clear();
      std::cin.ignore(10000, '\n');
   }

   switch(choice){
      case 1:
         playAll(head);
         break;
      
      case 2:
      {
         std::string newTrack = "";
         std::cout<<"Enter Track Name to Add: ";
         std::cin.ignore();
         std::getline(std::cin, newTrack);
         addSong(std::string(newTrack), &head);
         break;
      }
      case 3:
      {
         std::string delTrack = "";
         std::cout<<"Enter Track Name to Delete: ";
         std::cin.ignore();
         std::getline(std::cin, delTrack);
         deleteSong(std::string(delTrack), &head);
         break;
      }
      case 4:
      playLoop(head);
      break;

      case 5:
      playNext(&currentSong);
      break;

      case 6:
      playPrev(&currentSong);
      break;

      case 7:
         break;

      default:
         std::cout<<"Invalid Choice\n";

      }

   }
   return 0;
}

/*
Create a playlist using multiple songs. done
Add songs to the playlist. done
Remove a song from the playlist. done
Play songs in a loop (for this activity, we will print all the songs once).*/

/*
Design the basic structure that supports circular data representation. done
After that, implement the insert and delete functions in the structure. done
Implement a function for traversing the playlist. done*/