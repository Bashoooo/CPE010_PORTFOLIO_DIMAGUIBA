#ifndef SIMPLY_LL_H
#define SIMPLY_LL_H

template <typename T>
class SimplyList{
    public:
        T data;
        SimplyList<T> *next = nullptr;
};

/*ListTraversal (parameter: pointer to node n)
WHILE n IS NOT EQUAL TO null
PRINT data OF n
GO TO NEXT NODE n := next
ENDWHILE
PRINT next line
END*/

template <typename T >
void listTraversal(SimplyList<T>* head){

    if (head == nullptr){
        std::cout<<"List is empty"<<std::endl;
        return;
    }

    while(head != nullptr){
        std::cout<<head->data;
        head = head->next;
    }

}


/*Steps:
1. Allocate memory for the new node
2. Put our data into the new node
3. Set Next of the new node to point to the previous Head
4. Reset Head to point to the new node*/

template<typename T>
void sllinserteHead(T newData, SimplyList<T>** currenthead){
    //Allocate memory for the new node
    SimplyList<T>* newNode = new SimplyList<T>;

    //Put our data into the new node
    newNode->data = newData;

    //Set Next of the new node to point to the previous Head
    newNode->next = *currenthead;

    //Reset Head to point to the new node
    *currenthead = newNode;

}

/*1. Check if it is the head node (previous node is null)
2. If null, print "Previous node cannot be null."
3. Allocate a new node
4. Store data in the new node
5. Point new node to the node previous node was pointing to
6. Point previous node to the new node*/
template <typename T>
void sllGeneralInsert(T newData, SimplyList<T>* prevNode){
   // Check if it is the head node (previous node is null)
    if (prevNode == nullptr){
        //If null, print "Previous node cannot be null."
        std::cout<<"Previous node cannot be null"<<std::endl;
        return;
    }
    //Allocate a new node
    SimplyList<T>* newNode = new SimplyList<T>;

    //Store data in the new node
    newNode->data = newData;

    //Point new node to the node previous node was pointing to
    newNode->next = prevNode->next;
    
    //Point previous node to the new node
    prevNode->next = newNode;

}

/*
1. Allocate new node
2. Dereference to the head node
3. Store data in new node
4. Point next of new node to NULL
5. Traverse the list until next of the node is null
6. Point the next of the current node to the new node*/

template <typename T>
void sllinsertEnd(T newData, SimplyList<T>**head){
   //1. Allocate new node
    SimplyList<T>* newNode = new SimplyList<T>;
    //Dereference to the head node
    SimplyList<T>* currentNode = *head;
    //3. Store data in new node
    newNode->data = newData;
    //Point next of new node to NULL
    newNode->next = nullptr;
    //Traverse the list until next of the node is null
    while(currentNode->next != nullptr){
        currentNode = currentNode->next;

    }

    //Point the next of the current node to the new node
    currentNode->next = newNode;
}

/*To delete a node from linked list, we need to do following steps.
1) Find previous node of the node to be deleted.
2) Change the next of previous node.
3) Free memory for the node to be deleted.*/

template<typename T>
void sllDeleteNode(T findData, SimplyList<T>** head){

    //check if there's nothing
    if (*head == nullptr){
        return;
    }

    SimplyList<T>* currNode = *head;
    SimplyList<T>* prevNode = nullptr;

    //searching
    while(currNode!= nullptr && currNode->data != findData){
        prevNode = currNode;
        currNode = currNode->next;
    }

    //data was not found:

    if(currNode == nullptr){
        return;
    }

    //if node to be deleted is the head?
    if(prevNode == nullptr){
        *head = currNode->next;
    }
    else{
        prevNode->next = currNode-> next;
    }

    //how to delete node?
    delete currNode;
}

template <typename T>
void sllDeleteList(SimplyList<T>** head){
    SimplyList<T>* current = *head;

    while(current != nullptr){
        SimplyList<T>* temp = current;
        current = current->next;
        delete temp;

    }
    *head = nullptr;
}

#endif