#include <iostream>
#include "simply_LL.h"
#include "double_LL.h"

int main(){

   DoubleList<char>* head = createNode('C');
   DoubleList<char>* second = createNode('P');
   DoubleList<char>* third = createNode('E');
    
   head->next = second;
   second->prev = head;

   second->next = third;
   third->prev = second;

   std::cout<<"Traversal"<<std::endl;
   dllTraverse(head);
   std::cout<<"\n";

   std::cout<<"Insert Head:"<<std::endl;
   dllinsertHead('X',&head);
   dllTraverse(head);
   std::cout<<"\n";

   std::cout<<"Insert End:"<<std::endl;
   dllinsertEnd('1',head);
   dllTraverse(head);
    std::cout<<"\n";

   std::cout<<"Gen Insert:"<<std::endl;
   dllGenIns('2',head->next->next);
   dllTraverse(head);
   std::cout<<"\n";

   std::cout<<"Delete Node:"<<std::endl;
   dllDeleteNode('2', &head);
   dllTraverse(head);
   std::cout<<"\n";

   std::cout<<"Delete List:"<<std::endl;
   dllDeleteListF(&head);
   dllTraverse(head);
   std::cout<<"\n";

   
   /*std::cout<<"Delete List Backwards:"<<std::endl;
   dllDeleteListB(&head);
   dllTraverse(head);
   std::cout<<"\n";*/

   return 0;
}