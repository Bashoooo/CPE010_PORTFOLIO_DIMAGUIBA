#include <iostream>
#include "simply_LL.h"

int main(){

    //Creating an empty list
    SimplyList<char>* head = new SimplyList<char>;;
    SimplyList<char>* second = new SimplyList<char>;
    SimplyList<char>* third = new SimplyList<char>;
    SimplyList<char>* fourth = new SimplyList<char>;
    SimplyList<char>* fifth = new SimplyList<char>;
    SimplyList<char>* sixth = new SimplyList<char>;


    //assign data:
    //node 1
    head->data = 'C';
    head->next = second;

    //node2
    second->data = 'P';
    second->next = third;

    //node3
    third->data = 'E';
    third->next = fourth;

    //node4
    fourth->data = '1';
    fourth->next = fifth;
    
     //node5
    fifth->data = '0';
    fifth->next = sixth;

    //node6
    sixth->data = '1';
    sixth->next = nullptr;

   std::cout<<"original list:"<<std::endl;
    listTraversal(head);

    //node insertion at head
    std::cout<<"\ninserting a new node at the head: \n";
    sllinserteHead('G',&head);
    listTraversal(head);

    std::cout<<"\ninserting a new node at the third: "<<std::endl;
    sllGeneralInsert('E', head->next->next);
    listTraversal(head);

    std::cout<<"\ndeleting a node: \n"<<std::endl;
    sllDeleteNode('C', &head);
    listTraversal(head);

    std::cout<<"\ndeleting a node: \n"<<std::endl;
    sllDeleteNode('P', &head);
    listTraversal(head);
    
    return 0;
}

