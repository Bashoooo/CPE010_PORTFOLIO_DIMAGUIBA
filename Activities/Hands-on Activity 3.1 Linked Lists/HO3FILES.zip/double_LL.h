#ifndef DOUBLE_LL_H
#define DOUBLE_LL_H

template <typename T>
class DoubleList{
    public:
        T data;
        DoubleList<T>* next = nullptr;
        DoubleList<T>* prev = nullptr;
};

//create new node
template <typename T>
DoubleList<T>* createNode(T newData){
    DoubleList<T>* newNode = new DoubleList<T>;

    newNode->data = newData;
    newNode->prev = nullptr;
    newNode->next = nullptr;

    return newNode;
}

template <typename T>
void dllTraverse(DoubleList<T>* currentHead){

    DoubleList<T>* tail = new DoubleList<T>;
    //checks if list empty
    if (currentHead == nullptr){
        std::cout<<"The list is empty"<<std::endl;
        return;
    }
    //forward traversing:
    std::cout<<"Forward"<<std::endl;
    //moves towards the last node till null
    while(currentHead != nullptr){
        std::cout<<currentHead->data<<" ";
        //saved last visited node
        tail = currentHead;
        //move to next node
        currentHead = currentHead->next;
    }

    std::cout<<"\n";
    //backward traversing:
    std::cout<<"Backward:"<<std::endl;
    //move towards head
    while(tail != nullptr){
        //pring data
        std::cout<<tail->data<<" ";
        //move to previous node
        tail = tail->prev;
    }
   
}

//Insert at the head
template <typename T>
void dllinsertHead(T newData, DoubleList<T>** currHead){
    //new node
    DoubleList<T>* newNode = createNode(newData);
    //new node point to the current head
    newNode->next = *currHead;
    //point prev
    (*currHead)->prev = newNode;
    //update pointer
    *currHead = newNode;
}
template <typename T>
void dllinsertEnd(T newData, DoubleList<T>* currHead){

    //create new node
    DoubleList<T>* newNode = createNode(newData);
    
    //traverse to last
    while(currHead->next != nullptr){
        currHead = currHead->next;
    }

    //connect
    currHead->next = newNode;
    //connect new node
    newNode->prev = currHead;
}

//Gen Insert
template <typename T>
void dllGenIns(T newData, DoubleList<T>* prevNode){
    //Create
    DoubleList<T>* newNode = createNode(newData);

    //check if empty
    if (prevNode == nullptr){
        std::cout<<"Previous node cannot be empty"<<std::endl;
        return;
    }

    //Insert
    newNode->next = prevNode->next;

    //if there is node after prevNode, point
    newNode->prev = prevNode;
    if(prevNode->next != nullptr){
        prevNode->next->prev = newNode;
    }

    prevNode->next = newNode;

}

template <typename T>
void dllDeleteNode(T findData, DoubleList<T>** head){

//if empty
if(*head == nullptr){
    return;
}
DoubleList<T>* currNode =*head;

//search 
while(currNode != nullptr && currNode->data != findData){
    currNode = currNode->next;
}

//if data is not found
if(currNode == nullptr){
    return;
}

//if deleting head
if(currNode == *head){
    *head = currNode->next;
    if(*head != nullptr){
        (*head)->prev = nullptr;
    }
} 
//points it back both next and prev
else {
    currNode->prev->next = currNode->next;
    if(currNode->next != nullptr){
        currNode->next->prev = currNode->prev;
    }
}

delete currNode;
}

template <typename T>
void dllDeleteListF(DoubleList<T>** head){
    DoubleList<T>* current = *head;

    while(current != nullptr){
        DoubleList<T>* temp = current;
        current = current->next;

        delete temp;

    }
    *head = nullptr;
}

template <typename T>
void dllDeleteListB(DoubleList<T>** head){
    DoubleList<T>* current = *head;
    DoubleList<T>* tail = new DoubleList<T>;

    //get to end first
    while(current->next != nullptr){
        tail = current;
        current = current->next;
    }
    //delete backwards
    while(tail != nullptr){
        DoubleList<T>* temp = tail;
        tail = tail->prev;
        delete temp;
    }
    *head = nullptr;
}

#endif