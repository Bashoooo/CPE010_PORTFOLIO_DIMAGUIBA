#include <iostream>
#include "genT.h"

int main(){

    //lvl 0
    GeneralTree<char>* root = new GeneralTree('A');

    //level 1
    root->insertFirst('B');
    root->insertSecond('C');
    root->insertThird('D');
    root->insertFourth('E');
    root->insertFifth('F');
    root->insertSixth('G');

    //level 2
    root->getThirdChild()->insertFirst('H');

    root->getFourthChild()->insertFirst('I');
    root->getFourthChild()->insertSecond('J');

    root->getFifthChild()->insertFirst('K');
    root->getFifthChild()->insertSecond('L');
    root->getFifthChild()->insertThird('M');

    root->getSixthChild()->insertFirst('N');

    //level 3
    root->getFourthChild()->getSecondChild()->insertFirst('P');
    root->getFourthChild()->getSecondChild()->insertSecond('Q');

    // "O" activity
    root->getSixthChild()->insertSecond('O');

    //traverse
    std::cout<<"Preorder Order: ";
    root->preOrder();
    
    std::cout<<"\nPostorder Order: ";
    root->postOrder();

    std::cout<<"\nInorder Order: ";
    root->inOrder();

    std::cout<<std::endl;
    root->findData(1, 'F'); //will not output anything if false

    root->findData(2, 'O'); //will not output anything if false





    return 0;
}

