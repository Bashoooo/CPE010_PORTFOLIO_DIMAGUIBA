#ifndef GENT_H
#define GENT_H
#include <iostream>

template<typename T>
class GeneralTree{

    private:
    T key;
    GeneralTree<T>* first;
    GeneralTree<T>* second;
    GeneralTree<T>* third;
    GeneralTree<T>* fourth;
    GeneralTree<T>* fifth;
    GeneralTree<T>* sixth;

    public:
    //constructor
    GeneralTree(T value);

    //insertion
    void insertFirst(T value);
    void insertSecond(T value);
    void insertThird(T value);
    void insertFourth(T value);
    void insertFifth(T value);
    void insertSixth(T value);

    //get positions
    T getRootVal();
    GeneralTree<T>* getFirstChild();
    GeneralTree<T>* getSecondChild();
    GeneralTree<T>* getThirdChild();
    GeneralTree<T>* getFourthChild();
    GeneralTree<T>* getFifthChild();
    GeneralTree<T>* getSixthChild();

    //traversal
    void preOrder();
    void postOrder();
    void inOrder();

    //search
    void findData(int choice, T search);
    void preOrderSearch(T search);
    void postOrderSearch(T search);
    void inOrderSearch(T search);
};

template <typename T>
GeneralTree<T>::GeneralTree(T value){
    key = value;
    first = nullptr;
    second = nullptr;
    third = nullptr;
    fourth = nullptr;
    fifth = nullptr;
    sixth = nullptr;
}
template <typename T>
T GeneralTree<T>::getRootVal(){ //for testing purposes
    return key;
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getFirstChild(){
    return first;
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getSecondChild(){
    return second;
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getThirdChild(){
    return third;
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getFourthChild(){
    return fourth;
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getFifthChild(){
    return fifth;
}

template <typename T>
GeneralTree<T>* GeneralTree<T>::getSixthChild(){
    return sixth;
}

template <typename T>
void GeneralTree<T>::insertFirst(T newNode){

    //if null
    if(first == nullptr){
        first = new GeneralTree<T>(newNode);
    }

    //if ever we want to add a node in a specific place
    else{
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);

        //move existing child below new node
        newChild->first = first;

        //make new node the child;
        first = newChild;

    }
}

template <typename T>
void GeneralTree<T>::insertSecond(T newNode){

    //if null
    if(second == nullptr){
        second = new GeneralTree<T>(newNode);
    }

    //if ever we want to add a node in a specific place
    else{
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);

        //move existing child below new node
        newChild->second = second;

        //make new node the child;
        second = newChild;

    }
}

template <typename T>
void GeneralTree<T>::insertThird(T newNode){

    //if null
    if(third == nullptr){
        third = new GeneralTree<T>(newNode);
    }

    //if ever we want to add a node in a specific place
    else{
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);

        //move existing child below new node
        newChild->third = third;

        //make new node the child;
        third = newChild;

    }
}

template <typename T>
void GeneralTree<T>::insertFourth(T newNode){

    //if null
    if(fourth == nullptr){
        fourth = new GeneralTree<T>(newNode);
    }

    //if ever we want to add a node in a specific place
    else{
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);

        //move existing child below new node
        newChild->fourth = fourth;

        //make new node the child;
        fourth = newChild;

    }
}

template <typename T>
void GeneralTree<T>::insertFifth(T newNode){

    //if null
    if(fifth == nullptr){
        fifth = new GeneralTree<T>(newNode);
    }

    //if ever we want to add a node in a specific place
    else{
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);

        //move existing child below new node
        newChild->fifth = fifth;

        //make new node the child;
        fifth = newChild;

    }
}

template <typename T>
void GeneralTree<T>::insertSixth(T newNode){

    //if null
    if(sixth == nullptr){
        sixth = new GeneralTree<T>(newNode);
    }

    //if ever we want to add a node in a specific place
    else{
        GeneralTree<T>* newChild = new GeneralTree<T>(newNode);

        //move existing child below new node
        newChild->sixth = sixth;

        //make new node the child;
        sixth = newChild;

    }
}

template <typename T>
void GeneralTree<T>::preOrder(){

    //Order:
    // root->first.....->sixth
    std::cout<< key << " ";
    
    if(first != nullptr){
        first->preOrder();
    }

    if(second != nullptr){
        second->preOrder();
    }

    if(third != nullptr){
        third->preOrder();
    }

    if(fourth != nullptr){
        fourth->preOrder();
    }

    if(fifth != nullptr){
        fifth->preOrder();
    }

    if(sixth != nullptr){
        sixth->preOrder();
    }
    

}

template <typename T>
void GeneralTree<T>::postOrder(){

    //Order:
    // first.....->sixth->root
    
    if(first != nullptr){
        first->postOrder();
    }

    if(second != nullptr){
        second->postOrder();
    }

    if(third != nullptr){
        third->postOrder();
    }

    if(fourth != nullptr){
        fourth->postOrder();
    }

    if(fifth != nullptr){
        fifth->postOrder();
    }

    if(sixth != nullptr){
        sixth->postOrder();
    }
    
    std::cout<< key << " ";

}

template <typename T>
void GeneralTree<T>::inOrder(){

    //Order:
    // first->root->......->sixth
    
    if(first != nullptr){
        first->inOrder();
    }

    std::cout<< key << " ";

    if(second != nullptr){
        second->inOrder();
    }

    if(third != nullptr){
        third->inOrder();
    }

    if(fourth != nullptr){
        fourth->inOrder();
    }

    if(fifth != nullptr){
        fifth->inOrder();
    }

    if(sixth != nullptr){
        sixth->inOrder();
    }
}

template <typename T>
void GeneralTree<T>::preOrderSearch(T search){

    //Order:
    // root->first.....->sixth
    if (key == search){
        std::cout<<key<<" was found!"<<std::endl;
        return;
    }
    
    if(first != nullptr){
        first->preOrderSearch(search);
    }

    if(second != nullptr){
        second->preOrderSearch(search);
    }

    if(third != nullptr){
        third->preOrderSearch(search);
    }

    if(fourth != nullptr){
        fourth->preOrderSearch(search);
    }

    if(fifth != nullptr){
        fifth->preOrderSearch(search);
    }

    if(sixth != nullptr){
        sixth->preOrderSearch(search);
    }
    

}

template <typename T>
void GeneralTree<T>::postOrderSearch(T search){

    //Order:
    // first.....->sixth->root
    
    if(first != nullptr){
        first->postOrderSearch(search);
    }

    if(second != nullptr){
        second->postOrderSearch(search);
    }

    if(third != nullptr){
        third->postOrderSearch(search);
    }

    if(fourth != nullptr){
        fourth->postOrderSearch(search);
    }

    if(fifth != nullptr){
        fifth->postOrderSearch(search);
    }

    if(sixth != nullptr){
        sixth->postOrderSearch(search);
    }
    
    if (key == search){
        std::cout<<key<<" was found!"<<std::endl;
        return;
    }

    
}

template <typename T>
void GeneralTree<T>::inOrderSearch(T search){

    //Order:
    // first->root->......->sixth
    
    if(first != nullptr){
        first->inOrderSearch(search);
    }

   if (key == search){
        std::cout<<key<<" was found!"<<std::endl;
        return;
    }

    if(second != nullptr){
        second->inOrderSearch(search);
    }

    if(third != nullptr){
        third->inOrderSearch(search);
    }

    if(fourth != nullptr){
        fourth->inOrderSearch(search);
    }

    if(fifth != nullptr){
        fifth->inOrderSearch(search);
    }

    if(sixth != nullptr){
        sixth->inOrderSearch(search);
    }
}

template <typename T>
void GeneralTree<T>::findData(int choice, T search){

    switch(choice){
        case 1:
            preOrderSearch(search);
            break;

        case 2:
            inOrderSearch(search);
            break;

        case 3:
            postOrderSearch(search);
            break;

        default:
            std::cout<<"Invalid Choice!"<<std::endl;
            return;
    }

}




#endif