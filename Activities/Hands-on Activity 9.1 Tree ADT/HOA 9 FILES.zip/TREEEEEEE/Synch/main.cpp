#include <iostream>
#include "BST.h"

int main(){

    BinarySearchTree<int>* tree = new BinarySearchTree(20);

    tree->insert(10);
    tree->insert(15);
    tree->insert(40);
    tree->insert(70);
    tree->insert(80);
    tree->insert(60);
 
    std::cout<<"Preorder output: ";
    tree->preOrder();
    std::cout<<std::endl;

    std::cout<<"Inorder output: ";
    tree->inOrder();
    std::cout<<std::endl;

    std::cout<<"Post output: ";
    tree->postOrder();
    std::cout<<std::endl;
 
 
    return 0;
}