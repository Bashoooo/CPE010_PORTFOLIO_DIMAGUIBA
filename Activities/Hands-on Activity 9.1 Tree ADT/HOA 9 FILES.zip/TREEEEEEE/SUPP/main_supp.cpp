#include <iostream>
#include "BST.h"
const int maxVal = 7;

int main(){

int inVal[maxVal] = {3, 9, 18, 0, 1, 4, 5};
BinarySearchTree<int>* tree = new BinarySearchTree(2);

    for (int i = 0; i < maxVal; i++){
        tree->insert(inVal[i]);

    }

    //optional
    /*
    tree->insert(3);
    tree->insert(9);
    tree->insert(18);
    tree->insert(0);
    tree->insert(1);
    tree->insert(4);
    tree->insert(5);
    */

    std::cout<<"Preorder output: ";
    tree->preOrder();
    std::cout<<std::endl;

    std::cout<<"Inorder output: ";
    tree->inOrder();
    std::cout<<std::endl;

    std::cout<<"Post output: ";
    tree->postOrder();
    std::cout<<std::endl;
 
 
    return 0;
}