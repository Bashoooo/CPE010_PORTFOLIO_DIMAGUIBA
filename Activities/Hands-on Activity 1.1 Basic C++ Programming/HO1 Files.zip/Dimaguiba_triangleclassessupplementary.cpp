#include <iostream>
#include <string>
//PascalCase
class Triangle{
    private:
        double totalAngle, angleA, angleB, angleC;
        double base, height,area;
    public:
        //constructor
        Triangle(double A, double B, double C,double bs, double ht);
        void setAngles(double A, double B, double C);
        const bool validateTriangle();
        void setArea(double bs, double ht);
        double displayArea();
        double perimeter(double side1, double side2, double side3);
        void triType();
};

int main(){

    Triangle setl(40,30,110,4,3);
    
    std::cout<<"Area: "<<setl.displayArea()<<" units\n\n";
	std::cout<<"Perimeter: "<<setl.perimeter(5,4,3)<<" units\n\n";

    if(setl.validateTriangle()){
        std::cout<<"The shape is a valid triangle\n";
        setl.triType();
    }
    else{
        std::cout<<"The shape is NOT a valid triangle\n";
    }
    
    return 0;
}

Triangle::Triangle(double A, double B, double C, double bs, double ht){
    angleA = A; 
    angleB = B;
    angleC = C;
    base = bs;
    height = ht;
    totalAngle = A + B + C;
    area = (0.5 * (base * height));
}

void Triangle::setAngles(double A, double B, double C){
    angleA = A; 
    angleB = B;
    angleC = C;
}

const bool Triangle::validateTriangle(){
    return (totalAngle <= 180);
}

void Triangle::setArea(double bs, double ht){
	base = bs;
	height = ht;
}
double Triangle::displayArea(){
	return area;
}
double Triangle::perimeter(double side1, double side2, double side3){
	return side1 + side2 + side3;
}

void Triangle::triType(){
	if (angleA == 90 || angleB == 90 || angleC == 90 ){ //if either has 90 degrees
		std::cout<<"A Right Triangle"<<std::endl;
	}
	else if (angleA > 90 || angleB > 90 || angleC > 90){
		std::cout<<"An Obtuse Triangle"<<std::endl; //when one is greater than 90
	}
	else{
		std::cout<<"An Acute Triangle"<<std::endl; // all are less than 90
	}
}



