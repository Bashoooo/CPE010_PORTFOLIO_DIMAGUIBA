#include <iostream>

void swapper(int aNum, int bNum);

int main(){
	int funnyNumber1, funnyNumber2, temp = 0;
	
	std::cout<<"Number Swapper:\n\n"; 
	std::cout<<"Enter the FIRST number, ANY NUMBER YOU PLEASE: "; //Flavor text, pls dont sue
	
	while(!(std::cin>>funnyNumber1)){
		std::cout<<"I SAID NUMBER. TRY. AGAIN.\n";
		std::cin.clear();
		std::cin.ignore(10000,'\n');
	}
	
	std::cout<<"Enter the SECOND number, ANY NUMBER YOU PLEASE: ";
	
	while(!(std::cin>>funnyNumber2)){
		std::cout<<"I SAID NUMBER. TRY. AGAIN.\n";
		std::cin.clear();
		std::cin.ignore(10000,'\n');
	}
	
	swapper(funnyNumber1, funnyNumber2);
	
	return 0;
}

void swapper(int aNum, int bNum){
	
	std::cout<<"Your current number order: "<<aNum<<" "<<bNum<<std::endl;
	int temp = aNum;
	aNum = bNum;
	bNum = temp;
	std::cout<<"SWAPPED: "<<aNum<<" "<<bNum<<std::endl;
	
}
