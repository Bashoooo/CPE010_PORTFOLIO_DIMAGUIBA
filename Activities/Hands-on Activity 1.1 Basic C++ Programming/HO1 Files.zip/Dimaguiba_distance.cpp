#include <iostream>
#include <cmath> // for squareroot
float distanceCalculator(float x1, float x2, float y1, float y2);
int main(){
	float x1,x2,y1,y2 = 0;
	
	std::cout<<"Enter first point (X): "<<std::endl;
    
    while(!(std::cin>>x1)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }
    
    std::cout<<"Enter second point (X): "<<std::endl;
    
    while(!(std::cin>>x2)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }
    
    std::cout<<"Enter first point (Y): "<<std::endl;
    
    while(!(std::cin>>y1)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }
    
    std::cout<<"Enter second point (Y): "<<std::endl;
    
    while(!(std::cin>>y2)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }
    
	std::cout<<distanceCalculator(x1,x2,y1,y2)<<" units";
	
	return 0;
}

float distanceCalculator(float x1, float x2, float y1, float y2){
	float solution = std::sqrt( pow((x2-x1),2) + pow((y2-y1),2) );
	return solution;
}
