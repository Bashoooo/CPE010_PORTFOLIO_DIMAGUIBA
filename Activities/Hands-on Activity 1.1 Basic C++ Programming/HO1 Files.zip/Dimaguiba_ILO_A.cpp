#include <iostream>

int sumOfTwo (int fNum, int sNum);
void sumOfThree(int fNum, int sNum, int tNum);
void comparator(float aNum, float bNum);
bool logicCheck (bool a,bool b);
 	
float aComp, bComp = 0;
bool aLogic, bLogic = 0;

int main(){
   
    
//Display the Sum part of ILO A
    std::cout<<"The sum of two numbers is:"<<sumOfTwo(6,7)<<std::endl;
    sumOfThree(6,7,8);

//Compare 2 values section of ILO A
    std::cout<<"Enter a value A (Comparison): "<<std::endl;
    
    while(!(std::cin>>aComp)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }

    std::cout<<"Enter a value B (Comparison): "<<std::endl;
    while(!(std::cin>>bComp)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }
    comparator(aComp,bComp);

    //Boolean
     std::cout<<"Enter a Boolean A (Comparison): "<<std::endl;
    
    while(!(std::cin>>aLogic)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }

    std::cout<<"Enter a Boolean B (Comparison): "<<std::endl;
    while(!(std::cin>>bLogic)){
        std::cout<<"Try again"<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }
    
    if (logicCheck (aLogic, bLogic)){
    	std::cout<<"Success!"<<std::endl;
	}

    return 0;
    
}

//Definitions
int sumOfTwo (int fNum, int sNum){
    int sum = fNum + sNum;
    return sum;
}

void sumOfThree(int fNum, int sNum, int tNum){
    std::cout<<"The total sum is: "<< fNum + sNum + tNum<<std::endl;
}

void comparator(float aNum, float bNum){
    if (aNum > bNum){
        std::cout<<aNum<<" is greater than "<<bNum<<std::endl;
    }

    else if (aNum == bNum){
        std::cout<<aNum<<" is equal to "<<bNum<<std::endl;
    }

    else {
        std::cout<<bNum<<" is greater than "<<aNum<<std::endl;
    }
}

bool logicCheck (bool a,bool b){
    std::cout<<"AND operation: ";
    if (a && b){
        std::cout<<"True\n";
    }

    else{
        std::cout<<"False\n";
    }

    std::cout<<"OR operation: ";
    if (a || b){
        std::cout<<"True\n";
    }

    else{
        std::cout<<"False\n";
    }

    std::cout<<"NOT operation:\n";
    std::cout<<"NOT A = "<<!a<<std::endl;
    std::cout<<"NOT B = "<<!b<<std::endl;
    
    return true;


}
