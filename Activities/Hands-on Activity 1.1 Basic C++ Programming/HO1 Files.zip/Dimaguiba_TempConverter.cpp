#include <iostream>
#include <stdlib.h> //to clear screen

float kelToFa(float kel);
float faToKel(float fah);

int main(){
	int selection = 0;
	float temperature= 0;
	int exitVal = 0;
	
	while(exitVal != 1){
	
	std::cout<<"Menu:\n1. Kelvin to Fahrenheit\n2. Fahrenheit to Kelvin\n3.Quit\n";
	std::cout<<"Select: ";
	
	while(!(std::cin>>selection)){
        std::cout<<"Try again\n "<<std::endl;
        std::cin.clear();
        std::cin.ignore(10000,'\n');
    }
    
    switch(selection){
	
    	
    	case 1:
    		std::cout<<"Enter temperature(Kelvin): ";
			while(!(std::cin>>temperature)){
		        std::cout<<"Try again\n "<<std::endl;
		        std::cin.clear();
		        std::cin.ignore(10000,'\n');
    		}
    		std::cout<<kelToFa(temperature)<<" degrees Fahrenheit\n\n"<<std::endl;
    		std::cout<<"Press Enter to Continue\n";
    		std::cin.get();
    		std::cin.ignore(10000,'\n');
    		system("cls");
    		break;
    	
    	case 2:
    		std::cout<<"Enter temperature(Fahrenheit): ";
			while(!(std::cin>>temperature)){
		        std::cout<<"Try again\n "<<std::endl;
		        std::cin.clear();
		        std::cin.ignore(10000,'\n');
    		}
    		std::cout<<faToKel(temperature)<<" degrees Kelvin\n\n"<<std::endl;
    		std::cout<<"Press Enter to Continue\n";
    		std::cin.get();
    		std::cin.ignore(10000,'\n');
    		system("cls");
    		break;
    	
    	case 3:
    		exitVal = 1;
    		std::cout<<"Quitting"<<std::endl;
    		break;
    		
    	default:
    		std::cout<<"Invalid Choice!\n";
    		break;
    	}
    		
}
	return 0;
}

float kelToFa(float kel){
	float solution = (kel * 1.8) - 459.67;
	return solution;
}

float faToKel(float fah){
	float solution = (fah + 459.67) * (5.0/9.0);
	return solution;
}

