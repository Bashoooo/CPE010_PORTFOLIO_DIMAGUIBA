#include <iostream>

//PascalCase
class Triangle{
    private:
        double totalAngle, angleA, angleB, angleC;
    public:
        //constructor
        Triangle(double A, double B, double C);
        void setAngles(double A, double B, double C);
        const bool validateTriangle();
};

int main(){

    Triangle setl(40,30,110);

    if(setl.validateTriangle()){
        std::cout<<"The shape is a valid triangle\n";
    }
    else{
        std::cout<<"The shape is NOT a valid triangle\n";
    }
    
    return 0;
}

Triangle::Triangle(double A, double B, double C){
    angleA = A; 
    angleB = B;
    angleC = C;
    totalAngle = A + B + C;
}

void Triangle::setAngles(double A, double B, double C){
    angleA = A; 
    angleB = B;
    angleC = C;
}

const bool Triangle::validateTriangle(){
    return (totalAngle <= 180);
}
