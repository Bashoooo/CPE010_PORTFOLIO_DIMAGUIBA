#include <iostream>
  
//store adjacency items
struct adjNode{
    int val, cost;
    adjNode* next;
};

//structure that store edges
struct graphEdge{
    int startVer, endVer, weight;
};

class Diagraph{
    private:
        //insert new nodes
        adjNode* getAdjListNode(int value, int weight, adjNode* head){
        adjNode* newNode = new adjNode;
        newNode->val = value;
        newNode->cost = weight;
        // point new to current head
        newNode->next = head;
        return newNode;
    }
    //number of nodes in graph
    int N; 
    
    public:
        adjNode** head;
        //constructor
        Diagraph (graphEdge edges[], int n, int N){
            //allocate
            head = new adjNode* [N]();
            this->N = N;

            //initialize head pointer for the verices
            for(unsigned i = 0; i < n; ++i){
                int start_ver = edges[i].startVer;
                int end_ver = edges[i].endVer;
                int weight = edges[i].weight;
                //insert to beginning
                adjNode* newNode = getAdjListNode(end_ver, weight, head[start_ver]);

                //point head to new node
                head[start_ver] = newNode;
            }
        }

        //Destructor
        ~Diagraph(){
            for (int i = 0; i < N; i++){
                adjNode* curr = head[i];
                while(curr != nullptr){
                    adjNode* temp = curr;
                    curr = curr->next;
                    delete temp;
                }
            }
        };

        //print all adjacent vertices of the vertex
        void display_AdjList(adjNode* ptr, int i){
            while (ptr != nullptr){
                std::cout<< "(" << i << ", "<< ptr->val << ", "<< ptr->cost<<") ";
                ptr = ptr->next;
            }
            std::cout<<std::endl;
        }
    };

        //Graph Implementation
        int main(){
            //graph the edges array
            graphEdge edges[] = {
            // (x, y, w) -> edge from x to y with weight w
                {0,1,2},{0,2,4},{1,4,3},{2,3,2},{3,1,4},{4,3,3}};
            int N = 6;
            //calculate number of edges
            int n = sizeof(edges)/sizeof(edges[0]);
            //construct graph
            Diagraph diagraph(edges, n, N);
            //print adjacency list representation of graph
            std::cout<<"Graph adjacency list "<<std::endl<<"(start_vertex, end_vertex, weight): "<<std::endl;
            for (int i = 0; i < N; i++){
                // display adjacent vertices of vertex i
                diagraph.display_AdjList(diagraph.head[i], i);
            }
            return 0;
        }





