#ifndef SORTINGSUPP_H
#define SORTINGSUPP_H
#include <iostream>


template <typename T>
int routine_smallest(T arr[], int k, int arrSize){
    int pos = k;

    T smallest = arr[k];

    for(int j = k + 1; j < arrSize; j++){
        if(arr[j] < smallest){
            smallest = arr[j];
            pos = j;
        }
    }

    return pos;
}

template <typename T>
void sortSelect(T arr[], int arrSize){
    int min;

    for(int i = 0; i < arrSize; i++){
        min = routine_smallest(arr, i, arrSize);
        T temp = arr[i];
        arr[i] = arr[min];
        arr[min] = temp;
    }
}

//Linear search:
template <typename T>
int instanceSearch (T arr[], T search, int arrSize){
    int instances = 0;
    for(int i = 0; i < arrSize; i++){
        if(arr[i] == search){
            instances++;
        }
    }
    std::cout<<"\nNumber of votes: "<<instances<<std::endl;
    return instances;
}

#endif