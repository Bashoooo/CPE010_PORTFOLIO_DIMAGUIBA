#include <iostream>
#include <string>
#include <cstdlib>
#include <time.h>
#include "sortingSupp.h"

const int maxSize = 100;
const int canditateNum = 5;
int main(){
    int votes[maxSize];
    std::string candidates[canditateNum] = {"Bo Dalton Capistrano", "Cornelius Raymon Agustín", "Deja Jayla Bañaga", "Lalla Brielle Yabut", "Franklin Relano Castro"};
    //create random dataset
    srand(time(0));
    for(int i = 0; i < maxSize; i++){
        votes[i] = rand() % 5 + 1;
    }

    std::cout<<"Unsorted Votes: ";
    
    for(int i = 0; i < maxSize; i++){
        std::cout<<votes[i]<<" ";
    }

    sortSelect(votes, maxSize);
    std::cout<<"\nSorted Votes: ";
    for(int i = 0; i < maxSize; i++){
        std::cout<<votes[i]<<" ";
    }

    //vote count
    int win, voteNum, highest = 0;
    bool tied; //check ties
    for (int i = 0; i < canditateNum; i++){
        std::cout<<"\n"<<candidates[i];
        voteNum = instanceSearch(votes, i + 1, maxSize);
        if(voteNum > highest){
            highest = voteNum;
            win = i;
            tied = false;
        }

        else if(voteNum == highest){
            tied = true;
        }

    }

    if(tied){
        std::cout<<"\nVotes Tied!";}

    else{
        std::cout<<"\nWinner: "<<candidates[win];
    }
    
    
    return 0;
}