#include <iostream>
#include <cstdlib>
#include <time.h>
#include "sorting.h"
const int maxSize = 100;

int main(){

    //ARRAY CREATION
    int dataset[maxSize];
    srand(time(0));

    for(int i = 0; i <maxSize; i++){
        dataset[i] = rand() % 10 + 1; //to limit size
    }

    //DISPLAY
    std::cout<<"Current Data Set: ";

    for(int i = 0; i < maxSize; i++){
        std::cout<<dataset[i]<<" ";
    }

    //Sorting Alorithm Functions:
    //Remove (//) to test which

    //bubbleSort(dataset, maxSize);

    //selectionSort(dataset, maxSize);

    insertionSort(dataset, maxSize);

    std::cout<<"\nSorted Data Set: ";

    for(int i = 0; i < maxSize; i++){
        std::cout<<dataset[i]<<" ";
    }

    return 0;
}
