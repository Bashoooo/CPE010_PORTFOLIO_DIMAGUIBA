#ifndef SEARCHINGALGO_H
#define SEARCHINGALGO_H
#include "node.h"
/*
N -> Boundary of the list
Item -> Searching number
Data -> Linear array
Step 1: I := 0
Step 2: Repeat while I <= n
If (item = data[i])
Print "Searching is successful"
Exit
Else
Print "Searching is Unsuccessful"
Exit*/

template <typename T>
void linearSearchArr(int arrSize, T dataFind, T list[]){
//Step 1: I := 0
    int i = 0;
//Step 2: Repeat while I <= n
//______________________________________
    while(i < arrSize){
        //If (item = data[i])
        if (dataFind == list[i]){
            //Print "Searching is successful"
            std::cout<<"Searching is successful!\n";
            return;
        }
        i++;
    }
    //Print "Searching is Unsuccessful"
    std::cout<<"Searching is Unsuccessful"<<std::endl;
//_________________________________________

    //alt (recommended)
/*
for (int i = 0; i < arrSize; i++){
    if (dataFind == list[i]){
            //Print "Searching is successful"
            std::cout<<"Searching is successful!\n";
            return;
        }
    //Print "Searching is Unsuccessful"
    std::cout<<"Searching is Unsuccessful"<<std::endl; */
}

template <typename T>
void linearSearchLL(T dataFind, Node<T>* head){
    while(head != nullptr){
        if (head->data == dataFind){
            std::cout<<"Searching Successful!"<<std::endl;
            return;
        }
        head = head->next;
    }
    std::cout<<"Search Unsuccessfull!"<<std::endl;
}

/*1. Traverse the singly linked list using two pointers.
2. Move one pointer by one step ahead and the other pointer by two steps.
3. When the fast pointer reaches the end of the singly linked list, the slow pointer will
reach the middle of the singly linked list.
4. Return slow pointer address*/
template <typename T>
Node<T>* getMiddle(Node<T>* start, Node<T>* last){

    Node<T>* slow = start;
    Node<T>* fast = start;

    while (fast != last && fast->next != last){

            //move slow one step
            slow = slow->next;

            //move fast two steps
            fast = fast->next->next;
    }

    return slow;
}


/*
1. Start node is set to head of the list and the last node is set to NULL.
2. Middle element is calculated using the two pointers approach discussed above.
3. If the middle element is same as the key to be searched, we return it.
4. Else if middle element is greater than the key to be searched, we have to search is the
right side of the singly linked list. So, we set start pointer to the next of middle
element.
5. Else if middle element is less than the key to be searched, we have to search is the left
side of the singly linked list. So, we set last pointer to the middle element.
6. If the key is found or the entire linked list gets traversed, we break the loop*/
template <typename T>
void binarySearchLL(Node<T>* start, T dataFind){
   //1. Start node is set to head of the list and the last node is set to NULL.
    Node<T>* last = nullptr;

    
    while(start != last){

    //2. Middle element is calculated using the two pointers approach discussed above.
    Node<T>* middle = getMiddle(start, last); //program will not end 

    //3. If the middle element is same as the key to be searched, we return it.
    if(middle->data == dataFind){
        std::cout<<"Search Successful!"<<std::endl;
        return;
    }

    //4. Else if middle element is greater than the key to be searched, we have to search is the left side of the singly linked list. So, we set start pointer to the next of middle element.
    else if(middle->data > dataFind){
        last = middle;
    }

    //5. Else if middle element is less than the key to be searched, we have to search is the right side of the singly linked list. So, we set last pointer to the middle element.
    else{
        start = middle->next;
    }
    //6. If the key is found or the entire linked list gets traversed, we break the loop
}

std::cout<<"Search Unsuccessful!"<<std::endl;
return;
}

//for array binary search
template <typename T>
void binarySearchAR(int arrSize, T dataFind, T list[]){
//define low, up, middle
int low = 0, up = arrSize -1, middle;

//loop while low is less than or equal to high
while(low <= up){
    //compute for middle
    middle = ((low + up)/2);
    //if data found is middle -> data found -> return
    if (dataFind == list[middle]){
        std::cout<<"The search element is found!\n";
        return;
    }
    else if (dataFind < list[middle]){
        up = middle -1;
    }

    else{
        low = middle + 1;
    }
}

//search not found
std::cout<<"Search element not found"<<std::endl;

}

#endif