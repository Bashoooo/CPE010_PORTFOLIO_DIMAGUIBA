#ifndef SEARCHINGALGO_H
#define SEARCHINGALGO_H
#include "node.h"

//array
template <typename T>
void linearSearchArr(int arrSize, T findData, T list[]){
    int comparisons = 0;
    for (int i = 0; i < arrSize; i++){
        comparisons = i;
        if (findData == list[i]){
            std::cout<<"Data found! Number of Comparisons: "<<++comparisons<<std::endl;
            return;
        }
    }
    std::cout<<"Unsuccessful Search!"<<std::endl;
}

template <typename T>
void linearInstance(int arrSize, T findData, T list[]){
    int instances = 0;
        for (int i = 0; i < arrSize; i++){
            if(list[i] == findData){
                instances++;
            }
        }
        if(instances == 0){
            std::cout<<"Data not found!"<<std::endl;
            return;
        }
        std::cout<<"Numer of instances: "<<instances<<std::endl;
}

//linked list
template <typename T>
void linearSearchLL(T findData, Node<T>* head){
    int comparisons = 0;
    while(head != nullptr){
        ++comparisons;
        if(head->data == findData){
            std::cout<<"Data found! Number of Comparisons: "<<comparisons<<std::endl;
            return;
        }
        head = head->next;
    }
    std::cout<<"Unsuccessful Search!"<<std::endl;
}

template <typename T>
void linearInstanceLL(T findData, Node<T>* head){
    int instances = 0;
    if(head == nullptr){
        std::cout<<"Nothing to search!"<<std::endl;
        return;
    }
    while(head != nullptr){
        
        if (head->data == findData){
            instances++;
        }
        head = head->next;
    }
    if (instances == 0){
        std::cout<<"Data not found!"<<std::endl;
        return;
    }
    std::cout<<"Numver of instances: "<<instances<<std::endl;
}

//display current list
template <typename T>
void viewAll(Node<T>* head){
    if(head == nullptr){
        std::cout<<"List Empty!"<<std::endl;
        return;
    }
    std::cout<<"Current Linked List: ";
    while(head != nullptr){
        std::cout<<head->data<<" ";
        head = head->next;
    }
    std::cout<<std::endl;
}

//BINARY SEARCH Array
template <typename T>
void binarySearchArr(int arrSize, T findData, T list[]){
    int low = 0 , up = arrSize-1, middle;
    while(low <= up){
        middle = ((low + up)/2);
        std::cout<<"Current Mid: "<<list[middle]<<std::endl; //show current mid
        if (findData == list[middle]){
            std::cout<<"Search Complete! Found at index: "<<middle<<std::endl;
            return;
        }

        else if (findData < list[middle]){
            up = middle - 1;      
        }

        else{
            low = middle + 1;
        }

    }

    std::cout<<"Search element not found"<<std::endl;
}

//recursive

template <typename T>
void RecursiveSearchArr(int arrSize, int low, int up, T findData, T list[]){
    int middle;
    if(up >= low){
        middle = ((low + up)/2);
        if (findData == list[middle]){
            std::cout<<"Search Complete! Found at index: "<<middle<<std::endl;
            return;
        }

        else if (findData < list[middle]){
            return RecursiveSearchArr(arrSize, low, middle-1, findData, list);      
        }

        else{
            return RecursiveSearchArr(arrSize, middle+1, up, findData, list);
        }

    }

    std::cout<<"Search element not found"<<std::endl;
}

//Linked list version:
//get middle
template <typename T>
Node<T>* getMiddle(Node<T>* start, Node<T>* last){
    Node<T>* slow = start;
    Node<T>* fast = start;

    while(fast != last && fast->next != last){
        slow = slow->next;
        fast = fast->next->next;
    }

    return slow;
}

template <typename T>
void binarySearchLL(Node<T>*start, T findData){
    Node<T>* last = nullptr;

    while(start != last){

        Node<T>*middle = getMiddle(start, last);

        if(middle->data == findData){
            std::cout<<"Search Successful!"<<std::endl;
            return;
        }

        else if(middle->data < findData){
            start = middle->next;
        }

        else{
            last = middle;
        }
    }

    std::cout<<"Search Unsuccessful!"<<std::endl;
}
#endif