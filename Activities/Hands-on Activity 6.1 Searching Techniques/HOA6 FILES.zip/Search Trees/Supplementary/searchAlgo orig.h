#ifndef SEARCHINGALGO_H
#define SEARCHINGALGO_H
#include "node.h"

//array
template <typename T>
void linearSearchArr(int arrSize, T findData, T list[]){
    int comparisons = 0;
    for (int i = 0; i < arrSize; i++){
        comparisons = i;
        if (findData == list[i]){
            std::cout<<"Data found! Number of Comparisons: "<<++comparisons<<std::endl;
            return;
        }
    }
    std::cout<<"Unsuccessful Search!"<<std::endl;
}

//linked list
template <typename T>
void linearSearchLL(T findData, Node<T>* head){
    int comparisons = 0;
    while(head != nullptr){
        ++comparisons;
        if(head->data == findData){
            std::cout<<"Data found! Number of Comparisons: "<<comparisons<<std::endl;
            return;
        }
        head = head->next;
    }
    std::cout<<"Unsuccessful Search!"<<std::endl;
}

//display current list
template <typename T>
void viewAll(Node<T>* head){
    if(head == nullptr){
        std::cout<<"List Empty!"<<std::endl;
        return;
    }
    std::cout<<"Current Linked List: ";
    while(head != nullptr){
        std::cout<<head->data<<" ";
        head = head->next;
    }
    std::cout<<std::endl;
}

#endif