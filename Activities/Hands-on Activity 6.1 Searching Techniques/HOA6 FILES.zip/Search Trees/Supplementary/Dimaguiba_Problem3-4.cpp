#include <iostream>
#include "node.h"
#include"searchAlgo.h"
//set
const int max_capacity = 10;

int main(){
    //PROBLEM 3 - 4
    int list[max_capacity] = {3, 5, 6, 8, 11, 12, 14, 15, 17, 18};
    std::cout<<"Current list: ";
    for (int i = 0; i < max_capacity; i++){
        std::cout<<list[i]<<" ";
    }
    std::cout<<std::endl;

    int userInput;
    std::cout<<"Search for what number?: ";
    std::cin>>userInput;

    binarySearchArr(max_capacity, userInput, list);

    //Linked list:
    Node<int> * num1 = new_node(3);
    Node<int> * num2 = new_node(5);
    Node<int> * num3 = new_node(6); 
    Node<int> * num4 = new_node(8);
    Node<int> * num5 = new_node(11);
    Node<int> * num6 = new_node(12);
    Node<int> * num7 = new_node(14);
    Node<int> * num8 = new_node(15);
    Node<int> * num9 = new_node(17);
    Node<int> * num10 = new_node(18);

    num1->next = num2;
    num2->next = num3;
    num3->next = num4;
    num4->next = num5;
    num5->next = num6;
    num6->next = num7;
    num7->next = num8;
    num8->next = num9;
    num9->next = num10;

    binarySearchLL(num1, userInput);
    

    //recursive:
    RecursiveSearchArr(max_capacity, 0, 9, 8, list);
    return 0;
}
