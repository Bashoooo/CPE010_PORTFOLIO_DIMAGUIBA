#include <iostream>
#include "node.h"
#include"searchAlgo.h"
//set
const int max_capacity = 10;

int main(){
    //PROBLEM 1 - 2
    int list[max_capacity] = {5, 18, 2, 19, 18, 0, 8, 14, 19, 14};

    //array
    std::cout<<"Current list: ";
    for (int i = 0; i < max_capacity; i++){
        std::cout<<list[i]<<" ";
    }
    std::cout<<std::endl;
    int userInput;
    std::cout<<"Search for what number?: ";
    std::cin>>userInput;
    linearSearchArr(max_capacity, userInput, list);
    linearInstance(max_capacity, userInput, list);

    //linked list
    //create linked list
    Node<int> * num1 = new_node(5);
    Node<int> * num2 = new_node(18);
    Node<int> * num3 = new_node(2); 
    Node<int> * num4 = new_node(19);
    Node<int> * num5 = new_node(18);
    Node<int> * num6 = new_node(0);
    Node<int> * num7 = new_node(8);
    Node<int> * num8 = new_node(14);
    Node<int> * num9 = new_node(19);
    Node<int> * num10 = new_node(14);
    
    num1->next = num2;
    num2->next = num3;
    num3->next = num4;
    num4->next = num5;
    num5->next = num6;
    num6->next = num7;
    num7->next = num8;
    num8->next = num9;
    num9->next = num10;

    viewAll(num1); // views entire list
    linearSearchLL(userInput, num1);
    linearInstanceLL(userInput, num1);
    
    return 0;
}
